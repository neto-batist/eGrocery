import 'package:dio/dio.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/error/exceptions.dart';

class ProductService {
  final DioClient dioClient;

  ProductService({required this.dioClient});

  Future<List<Map<String, dynamic>>> fetchProducts() async {
    try {
      final response = await dioClient.get('/products');

      // Aqui pegamos a lista dentro de "content"
      final data = response.data;
      if (data is Map<String, dynamic> && data['content'] is List) {
        return List<Map<String, dynamic>>.from(data['content']);
      } else {
        throw ServerException('Formato inesperado na resposta da API');
      }
    } on DioException catch (e) {
      throw ServerException('Erro ao buscar produtos: ${e.message}');
    } catch (e) {
      throw ServerException('Erro desconhecido ao buscar produtos: $e');
    }
  }
}
